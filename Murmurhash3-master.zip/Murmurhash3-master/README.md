## MurmurHash3

java实现的MurmurHash3算法

详情请参考 https://en.wikipedia.org/wiki/MurmurHash

